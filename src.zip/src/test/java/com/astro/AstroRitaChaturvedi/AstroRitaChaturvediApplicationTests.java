package com.astro.AstroRitaChaturvedi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AstroRitaChaturvediApplicationTests {

	@Test
	void contextLoads() {
	}

}
