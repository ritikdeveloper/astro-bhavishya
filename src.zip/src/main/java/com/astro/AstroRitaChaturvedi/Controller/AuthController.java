package com.astro.AstroRitaChaturvedi.Controller;

import com.astro.AstroRitaChaturvedi.Model.UserModel;
import com.astro.AstroRitaChaturvedi.Security.JwtUtil;
import com.astro.AstroRitaChaturvedi.Service.UserService;
import com.astro.AstroRitaChaturvedi.Service.PhoneEmailService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    @Autowired
    private UserService userService;

    @Autowired
    private AuthenticationManager authenticationManager;

    @Autowired
    private JwtUtil jwtUtil;

    @Autowired
    private PhoneEmailService phoneEmailService;

    // DTO for phone.email registration
    public static class PhoneEmailRegisterRequest extends UserModel {
        private String userJsonUrl;

        public String getUserJsonUrl() {
            return userJsonUrl;
        }

        public void setUserJsonUrl(String userJsonUrl) {
            this.userJsonUrl = userJsonUrl;
        }
    }

    @PostMapping("/register-with-phone-email")
    public ResponseEntity<?> registerWithPhoneEmail(@RequestBody PhoneEmailRegisterRequest request) {
        if (request.getUserJsonUrl() == null || request.getUserJsonUrl().trim().isEmpty()) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(Map.of("error", "userJsonUrl is required"));
        }
        if (request.getUsername() == null || request.getUsername().trim().isEmpty()) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(Map.of("error", "Username is required"));
        }
        if (request.getPassword() == null || request.getPassword().trim().isEmpty()) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(Map.of("error", "Password is required"));
        }

        PhoneEmailService.PhoneEmailUserDetails phoneDetails = phoneEmailService.fetchUserDetails(request.getUserJsonUrl());

        if (phoneDetails == null || phoneDetails.fullPhoneNumber == null) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(Map.of("error", "Could not verify phone number via Phone.email service."));
        }

        // Check if phone number already exists
        if (userService.userExistsByPhoneNumber(phoneDetails.fullPhoneNumber)) {
            return ResponseEntity.status(HttpStatus.CONFLICT).body(Map.of("error", "This phone number is already registered. Please try logging in."));
        }

        // Check if username already exists
        if (userService.userExists(request.getUsername())) {
            return ResponseEntity.status(HttpStatus.CONFLICT).body(Map.of("error", "Username already exists"));
        }


        UserModel userToRegister = new UserModel();
        userToRegister.setUsername(request.getUsername());
        userToRegister.setPassword(request.getPassword()); // Password will be encoded by userService
        userToRegister.setEmail(request.getEmail());
        userToRegister.setFullName(request.getFullName() != null ? request.getFullName() : (phoneDetails.firstName + " " + phoneDetails.lastName).trim());
        userToRegister.setPhoneNumber(phoneDetails.fullPhoneNumber); // Set verified phone number
        userToRegister.setDateOfBirth(request.getDateOfBirth());
        // userToRegister.setRole(UserModel.UserRole.USER); // Default role

        try {
            UserModel registeredUser = userService.registerUserViaPhoneEmail(userToRegister);

            // Generate token for immediate use
            final UserDetails userDetails = userService.loadUserByUsername(registeredUser.getUsername());
            final String jwt = jwtUtil.generateToken(userDetails);

            Map<String, Object> response = new HashMap<>();
            response.put("message", "User registered successfully with verified phone number.");
            response.put("token", jwt);
            response.put("role", registeredUser.getRole());
            response.put("userId", registeredUser.getCustomerId());

            return ResponseEntity.ok(response);

        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(Map.of("error", e.getMessage()));
        }
    }

    @PostMapping("/login-with-phone-email")
    public ResponseEntity<?> loginWithPhoneEmail(@RequestBody Map<String, String> payload) {
        String userJsonUrl = payload.get("userJsonUrl");
        if (userJsonUrl == null || userJsonUrl.trim().isEmpty()) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(Map.of("error", "userJsonUrl is required"));
        }

        PhoneEmailService.PhoneEmailUserDetails phoneDetails = phoneEmailService.fetchUserDetails(userJsonUrl);

        if (phoneDetails == null || phoneDetails.fullPhoneNumber == null) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(Map.of("error", "Could not verify phone number via Phone.email service."));
        }

        try {
            UserModel user = userService.findUserByPhoneNumber(phoneDetails.fullPhoneNumber);
            if (user == null || !user.isVerified()) { // Ensure user exists and is verified
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(Map.of("error", "User with this phone number not found or not verified. Please register."));
            }

            // If phone number is the primary identifier and password is not used for this flow:
            final UserDetails userDetails = userService.loadUserByUsername(user.getUsername()); // Or a new method loadUserByPhoneNumber
            final String jwt = jwtUtil.generateToken(userDetails);

            Map<String, Object> response = new HashMap<>();
            response.put("token", jwt);
            response.put("role", user.getRole());
            response.put("userId", user.getCustomerId());
            response.put("message", "Login successful.");

            return ResponseEntity.ok(response);

        } catch (UsernameNotFoundException e) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(Map.of("error", "User with this phone number not found. Please register."));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(Map.of("error", "An error occurred during login: " + e.getMessage()));
        }
    }


    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody UserModel loginRequest) {
        try {
            if (loginRequest.getUsername() == null || loginRequest.getPassword() == null) {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                        .body(Map.of("error", "Username and password are required"));
            }

            final UserDetails userDetails = userService.loadUserByUsername(loginRequest.getUsername());

            authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(loginRequest.getUsername(), loginRequest.getPassword())
            );

            final String jwt = jwtUtil.generateToken(userDetails);

            Map<String, Object> response = new HashMap<>();
            response.put("token", jwt);
            response.put("role", ((UserModel) userDetails).getRole());
            response.put("userId", ((UserModel) userDetails).getCustomerId());

            return ResponseEntity.ok(response);
        } catch (UsernameNotFoundException e) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(Map.of("error", "User not found"));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(Map.of("error", "Invalid credentials: " + e.getMessage()));
        }
    }

    @PostMapping("/register")
    public ResponseEntity<?> userRegister(@RequestBody UserModel user) {
        try {
            Map<String, Object> debugInfo = new HashMap<>();
            debugInfo.put("receivedUsername", user.getUsername());
            debugInfo.put("receivedPassword", user.getPassword() != null ? "Password provided" : "Password is null");
            debugInfo.put("receivedEmail", user.getEmail());
            debugInfo.put("receivedPhoneNumber", user.getPhoneNumber());

            System.out.println("Debug info: " + debugInfo);

            if (user.getUsername() == null || user.getUsername().trim().isEmpty()) {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                        .body(Map.of("error", "Username is required", "debug", debugInfo));
            }

            if (user.getPassword() == null || user.getPassword().trim().isEmpty()) {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                        .body(Map.of("error", "Password is required", "debug", debugInfo));
            }

            if (userService.userExists(user.getUsername())) {
                return ResponseEntity.status(HttpStatus.CONFLICT).body(Map.of("error", "User already exists"));
            }
            // This old registration now relies on manual OTP.
            // Consider deprecating or clearly distinguishing if Phone.email is primary.
            UserModel registeredUser = userService.registerUser(user);
            return ResponseEntity.ok(Map.of(
                    "message", "User registration initiated. Please verify with OTP sent to your phone (if provided and old flow used).",
                    "userId", registeredUser.getCustomerId()
                    // "otp", registeredUser.getOtp() // Only for testing, remove in production
            ));
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(Map.of("error", e.getMessage()));
        }
    }

    @PostMapping("/verify-otp")
    public ResponseEntity<?> verifyOtp(@RequestBody Map<String, String> request) {
        // This endpoint might become less relevant if Phone.email is the primary verification.
        try {
            String username = request.get("username");
            String otp = request.get("otp");

            if (username == null || otp == null) {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                        .body(Map.of("error", "Username and OTP are required"));
            }

            if (userService.verifyOtp(username, otp)) {
                UserDetails userDetails = userService.loadUserByUsername(username);
                final String jwt = jwtUtil.generateToken(userDetails);

                Map<String, Object> response = new HashMap<>();
                response.put("token", jwt);
                response.put("role", ((UserModel) userDetails).getRole());
                response.put("userId", ((UserModel) userDetails).getCustomerId());

                return ResponseEntity.ok(response);
            } else {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(Map.of("error", "Invalid OTP"));
            }
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(Map.of("error", e.getMessage()));
        }
    }

    // ... other existing methods (register-admin, test, etc.)
    @GetMapping("/test")
    public ResponseEntity<?> testEndpoint() {
        return ResponseEntity.ok(Map.of("message", "Auth controller is working"));
    }

    @PostMapping("/register-admin")
    public ResponseEntity<?> registerAdmin(@RequestBody UserModel user) {
        try {
            if (user.getUsername() == null || user.getUsername().trim().isEmpty()) {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                        .body(Map.of("error", "Username is required"));
            }

            if (user.getPassword() == null || user.getPassword().trim().isEmpty()) {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                        .body(Map.of("error", "Password is required"));
            }

            if (userService.userExists(user.getUsername())) {
                return ResponseEntity.status(HttpStatus.CONFLICT).body(Map.of("error", "User already exists"));
            }

            UserModel registeredAdmin = userService.createAdminUser(user);
            final String jwt = jwtUtil.generateToken(registeredAdmin);

            Map<String, Object> response = new HashMap<>();
            response.put("message", "Admin user created successfully");
            response.put("userId", registeredAdmin.getCustomerId());
            response.put("token", jwt);
            response.put("role", registeredAdmin.getRole());

            return ResponseEntity.ok(response);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(Map.of("error", e.getMessage()));
        }
    }
}
