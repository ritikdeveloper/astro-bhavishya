package com.astro.AstroRitaChaturvedi.Controller;

import com.astro.AstroRitaChaturvedi.Model.UserModel;
import com.astro.AstroRitaChaturvedi.Security.JwtUtil;
import com.astro.AstroRitaChaturvedi.Service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

@RestController
@RequestMapping("/api/auth/user")
public class UserController {

    @Autowired
    private UserService userService;

    @Autowired
    private AuthenticationManager authenticationManager;

    @Autowired
    private JwtUtil jwtUtil;

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody UserModel loginRequest) {
        try {
            final UserDetails userDetails = userService.loadUserByUsername(loginRequest.getUsername());

            authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(loginRequest.getUsername(), loginRequest.getPassword())
            );

            final String jwt = jwtUtil.generateToken(userDetails);

            Map<String, String> response = new HashMap<>();
            response.put("token", jwt);
            return ResponseEntity.ok(response);
        } catch (UsernameNotFoundException e) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(Map.of("error", "User not found"));
        } catch (Exception e) {

            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(Map.of("error", "Invalid credentials"));
        }
    }


    @PostMapping("/register")
    public ResponseEntity<?> userRegister(@RequestBody UserModel user) {
        if (userService.userExists(user.getUsername())) {
            return ResponseEntity.status(HttpStatus.CONFLICT).body(Map.of("error", "User already exists"));
        }
        userService.registerUser(user);
        return ResponseEntity.ok("User registered successfully");
    }
    @GetMapping("/details/{id}")
    public ResponseEntity<?> userdetails (@PathVariable UUID id) {
        return ResponseEntity.status(200).body(userService.getUserById(id));
    }
    @PutMapping("/update/{id}")
    public ResponseEntity<?> updateUserProfile(@PathVariable UUID id, @RequestBody UserModel userUpdateRequest) {
        // Ensure the authenticated user is the one making the change or is an admin
        // For simplicity, we'll assume the JWT filter handles authentication.
        // More robust authorization would check if the authenticated user's ID matches 'id' or if the user is an ADMIN.

        try {
            UserModel updatedUser = userService.updateUserProfile(id, userUpdateRequest);
            return ResponseEntity.ok(updatedUser);
        } catch (UsernameNotFoundException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(Map.of("error", e.getMessage()));
        } catch (RuntimeException e) {
            // Catch more specific exceptions if needed, e.g., for validation errors
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(Map.of("error", e.getMessage()));
        }
    }


}
