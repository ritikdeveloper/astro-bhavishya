package com.astro.AstroRitaChaturvedi.Repository;

import com.astro.AstroRitaChaturvedi.Model.TransactionModel;
import com.astro.AstroRitaChaturvedi.Model.UserModel;
import com.astro.AstroRitaChaturvedi.Model.WalletModel;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface TransactionRepository extends JpaRepository<TransactionModel, UUID> {
    List<TransactionModel> findByUser(UserModel user);
    List<TransactionModel> findByWallet(WalletModel wallet);
    Optional<TransactionModel> findByRazorpayOrderId(String razorpayOrderId);
    Optional<TransactionModel> findByRazorpayPaymentId(String razorpayPaymentId);
}
